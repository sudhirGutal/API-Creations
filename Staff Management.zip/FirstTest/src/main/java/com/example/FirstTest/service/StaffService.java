package com.example.FirstTest.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.FirstTest.Utility.GetSorted;
import com.example.FirstTest.Utility.SortByName;
import com.example.FirstTest.dao.StaffDao;
import com.example.FirstTest.entity.Staff;

@Service
public class StaffService {
@Autowired
StaffDao sd;
public List<Staff> getAllRecords() {
	List<Staff> l=sd.getAllRecords();
	return l;
}
public List<Staff> getByExp() {
	List<Staff> l=sd.getByExp();
	return l;
}
public List<Staff> getById(int staffid) {
	List<Staff> l=sd.getByid(staffid);
	return l;
}
public String insertData(int staffid,String name,String profile,int salary,int experience) {
	return sd.insertData(staffid, name, profile, salary, experience);
}
public List<Staff> getMoreThan20000() {
	List<Staff> l=sd.getMoreThan20000();
	return l;
}
public List<Staff> maxSalary() {
	List<Staff> l=sd.maxSalary();
	return l;
}
public List<Staff> sortBySalary(){
	List<Staff> l=sd.getAllRecords();
	Collections.sort(l,new GetSorted());
	return l;
}
public List<Staff> sortByName(){
	List<Staff> l=sd.getAllRecords();
	Collections.sort(l,new SortByName());
	return l;
}
public String updateSalary(int staffid,int salary) {
	return sd.updateSalary(staffid, salary);
}
public String minExp() {
	return sd.minExp();
}
public List<Staff> getTrainers() {
return sd.getTrainers();	
}
public ArrayList<String> getNoTrainers() {
	return sd.getNoTrainers();
}
public String deleteData(int staffid) {
	return sd.deleteData(staffid);
}
}
