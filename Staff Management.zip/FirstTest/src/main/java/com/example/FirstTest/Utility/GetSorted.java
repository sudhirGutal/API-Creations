package com.example.FirstTest.Utility;


import java.util.Comparator;

import com.example.FirstTest.entity.Staff;

public class GetSorted implements Comparator<Staff>{

	@Override
	public int compare(Staff o1, Staff o2) {
		Integer salary1=o1.getSalary();
		Integer salary2=o2.getSalary();
		Integer exp1=o1.getExperience();
		Integer exp2=o2.getExperience();
		
		if(salary1.equals(salary2)) {
		return	exp1.compareTo(exp2);
		}else {
			return salary2.compareTo(salary1);
		}
		
	}
}
