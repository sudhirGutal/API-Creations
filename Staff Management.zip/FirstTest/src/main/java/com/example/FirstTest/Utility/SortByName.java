package com.example.FirstTest.Utility;

import java.util.Comparator;

import com.example.FirstTest.entity.Staff;

public class SortByName implements Comparator<Staff>{

	@Override
	public int compare(Staff o1, Staff o2) {
		return o1.getName().compareTo(o2.getName());
	}

}
