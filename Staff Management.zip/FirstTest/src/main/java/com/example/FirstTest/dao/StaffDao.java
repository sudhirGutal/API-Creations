package com.example.FirstTest.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.FirstTest.entity.Staff;

@Repository
public class StaffDao {
    @Autowired
	SessionFactory sf;
  public  List<Staff> getAllRecords() {
    	Session ss=sf.openSession();
    	Criteria cr=ss.createCriteria(Staff.class);
    	List<Staff> l=cr.list();
    	ss.close();
    	return l;
    }
public List<Staff> getByExp() {
	Session ss=sf.openSession();
	Criteria cr=ss.createCriteria(Staff.class);
	cr.add(Restrictions.between("experience", 10, 20));
	List<Staff> l=cr.list();
	ss.close();
	return l;
}
public List<Staff> getByid(int staffid) {
	Session ss=sf.openSession();
	Criteria cr=ss.createCriteria(Staff.class);
	cr.add(Restrictions.eq("staffid", staffid));
	List<Staff> l=cr.list();
	ss.close();
	return l;
}
public  String insertData(int staffid,String name,String profile,int salary,int experience) {
	Session ss=sf.openSession();
	Transaction tr=ss.beginTransaction();
	Staff sf=new Staff();
	sf.setStaffid(staffid);
	sf.setName(name);
	sf.setProfile(profile);
	sf.setSalary(salary);
	sf.setExperience(experience);
	ss.save(sf);
	tr.commit();
	ss.close();
	return "values inserted";
}
public List<Staff> getMoreThan20000() {
	Session ss=sf.openSession();
	Criteria cr=ss.createCriteria(Staff.class);
	cr.add(Restrictions.gt("salary", 20000));
	List<Staff> l=cr.list();
	ss.close();
	return l;
}
public List<Staff> maxSalary() {
	Session ss=sf.openSession();
	Criteria cr=ss.createCriteria(Staff.class);
	cr.addOrder(Order.desc("salary"));
	cr.setMaxResults(1);
	List<Staff> l=cr.list();
	ss.close();
	return l;
}
public String updateSalary(int staffid,int salary) {
	String name=null;
	String profile=null;
	int experience=0;
	List<Staff> l=getAllRecords();
	for (Staff staff : l) {
		if(staff.getStaffid()==staffid) {
			name=staff.getName();
			profile=staff.getProfile();
			experience=staff.getExperience();
		}
	}
	Session ss=sf.openSession();
	Transaction tr=ss.beginTransaction();
	Staff sf=new Staff();
	sf.setStaffid(staffid);
	sf.setName(name);
	sf.setProfile(profile);
	sf.setExperience(experience);
	sf.setSalary(salary);	
	ss.update(sf);
	tr.commit();
	ss.close();
	return "values updated";
}
public String minExp() {
	Session ss=sf.openSession();
	Criteria cr=ss.createCriteria(Staff.class);
	cr.addOrder(Order.asc("experience"));
	cr.setMaxResults(1);
	List<Staff> l=cr.list();
	String str = null;
	for (Staff staff : l) {
		str=staff.getName();
	}
	ss.close();
	return str;
}
public List<Staff> getTrainers() {
	Session ss=sf.openSession();
	Criteria cr=ss.createCriteria(Staff.class);
	cr.add(Restrictions.eq("profile", "trainer"));
	List<Staff> l=cr.list();
	ss.close();
	return l;	
}
public ArrayList<String> getNoTrainers() {
	Session ss=sf.openSession();
	Criteria cr=ss.createCriteria(Staff.class);
	cr.add(Restrictions.ne("profile", "trainer"));
	List<Staff> ll=cr.list();
	ArrayList<String> l=new ArrayList<>();
	for (Staff staff : ll) {
		l.add(staff.getName());
	}
	ss.close();
	return l;	
}

public  String deleteData(int staffid) {
	
	Session ss=sf.openSession();
	Transaction tr=ss.beginTransaction();
	Staff sf=ss.get(Staff.class, staffid);
	sf.setStaffid(staffid);
	ss.delete(sf);
	tr.commit();
	ss.close();
	return "values deleted";
	
}
}
