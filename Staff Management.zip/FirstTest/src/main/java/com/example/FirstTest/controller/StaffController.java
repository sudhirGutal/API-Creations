package com.example.FirstTest.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.FirstTest.entity.Staff;
import com.example.FirstTest.service.StaffService;

@RestController
public class StaffController {
	
@Autowired
StaffService ss;
@GetMapping("/getAll")
	List<Staff> getAllRecords() {
		List<Staff> l=ss.getAllRecords();
		return l;
	}
@GetMapping("/getByExp")
List<Staff> getBySalary() {
	List<Staff> l=ss.getByExp();
	return l;
}
@GetMapping("/getById")
List<Staff> getById(@RequestParam int staffid) {
List<Staff> l=ss.getById(staffid);
return l;
}
@RequestMapping("/insert")
String insertData(@RequestParam  int staffid,String name,String profile,int salary,int experience) {
	String str=ss.insertData(staffid, name, profile, salary, experience);
	return str;
}
@GetMapping("/getMoreThan20000")
List<Staff> getMoreThan20000() {
	List<Staff> l=ss.getMoreThan20000();
	return l;
}
@RequestMapping("/maxSalary")
List<Staff> maxSalary() {
	List<Staff> l=ss.maxSalary();
	return l;
}
@RequestMapping("/update")
String updateSalary(@RequestParam int staffid,int salary) {
	return ss.updateSalary(staffid, salary);
}
@GetMapping("/minSalary")
String minExp() {
	return ss.minExp();
}
@GetMapping("/getTrainers")
List<Staff> getTrainers() {
	return ss.getTrainers();
}
@GetMapping("/noTrainers")
ArrayList<String> getNoTrainers() {
	return ss.getNoTrainers();
}
@RequestMapping("sortBySalary")
	
	public List<Staff> sortBySalary(){
		return ss.sortBySalary();
	}
@RequestMapping("sortByName")
public List<Staff> sortByName(){
	return ss.sortByName();
}
	

@RequestMapping("delete")
String deleteData(@RequestParam int staffid) {
	return ss.deleteData(staffid);
}
}
