package com.example.FirstTest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
